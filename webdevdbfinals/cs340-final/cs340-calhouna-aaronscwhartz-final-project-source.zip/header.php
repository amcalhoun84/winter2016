<?php 
	include 'connect_db.php'; 
?>

<!DOCTYPE html>
<html>
<head>
	<?php echo("<title>$page_title</title>"); ?>
	<meta charset="utf-8" />
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<style></style>

</head>

<body>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="game.php">Games</a></li>
			<li><a href="genre.php">Genre</a></li>
			<li><a href="review.php">Reviews</a></li>
			<li><a href="platform.php">Platforms</a></li>
			<li><a href="rating.php">Rating System</a></li>
		</ul>
	</nav>

